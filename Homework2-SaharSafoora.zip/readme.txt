use the following commands to run the program:

./safarTech input_file minimum_support output_file

If you happen to edit the code, use the following commands to recompile:

rm safarTech
c++ -o safarTech *.cpp

- Sahar and Safoora

